# D-117 Qwen3-1.7B floor campaign — status governed by the D-134 freeze receipt

Pack identity: `d117_floor_qwen3-1p7b_v5` (`_v5`).

This description does not carry freeze status. The committed D-134 freeze receipt and its plan-tree attachment are authoritative for this pack's frozen state; the receipt pins `calibration_plan.json` by SHA, so this text and every serialized `draft_status` field stay exactly as generated on both sides of the freeze. An external unexpired PASS/GO arm receipt is required before launch.

This pack pre-registers the alpha window's 10 absolute decode members, ten null A/B/B/A blocks (40 members), and a zero-member prefill metric rider over the same 50 physical bundles. It also carries a dedicated D-166 p2048 prefill domain with 10 absolute members and ten null A/B/B/A blocks (50 additional members), plus three D-123 reported phase-energy means. The p2048 workload name remains `df_ph_prefill_p2048_candidate` for byte identity with the gamma consumer even though Q1 has frozen its prompt.

Its receipt oracle is replay-derived from `joulewise.calibration_ledger`: 10 physical receipts for 5 logical operations per finalized pre/post bracket session. Actual receipt bytes and the absolute terminal sequence remain arm-time evidence. Arm-time identities require U11 projection, and lead review must complete before any later release step.

A successor acceptance artifact issuing before arm REQUIRES a newly generated pack; the committed D-134 freeze receipt and its plan-tree attachment are authoritative for this pack's freeze state (the D-125 lineage-envelope alternative is recorded as a freeze-time lead decision).

Generate or verify with:

```text
python3 configs/campaigns/d117_floor_qwen3-1p7b_v5/generate_configs.py --prefill-prompt-pin /path/to/issued/prefill-prompt-pin.json
python3 configs/campaigns/d117_floor_qwen3-1p7b_v5/generate_configs.py --check
```

Integrity SHA-256 values in this pack detect drift; they do not mark release.
