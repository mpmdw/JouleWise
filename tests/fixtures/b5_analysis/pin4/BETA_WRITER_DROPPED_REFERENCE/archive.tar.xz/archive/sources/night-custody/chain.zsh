#!/bin/zsh
echo b5 test chain
