# Registration (test copy)

## 6. Flags and exclusions

### 6.8 Disclosed only

Text.

### 6.9 Harvest thresholds

The harvest reads its own copy of the in-window thresholds.

```json
{
  "battery_limit_ma": 200,
  "battery_unmeasured_gap_s": 120.0,
  "battery_accumulator_watts_per_unit": 0.001,
  "thermal_unmeasured_gap_s": 15.0,
  "contention_cpu_s_per_s": 0.05,
  "clock_step_ns": 1000000,
  "clock_unmeasured_gap_s": 3.0,
  "disk_low_bytes": 10737418240,
  "clock_systematic_min_recorded": 5
}
```

## 7. Verdicts

```json
{"battery_limit_ma": 1}
```
