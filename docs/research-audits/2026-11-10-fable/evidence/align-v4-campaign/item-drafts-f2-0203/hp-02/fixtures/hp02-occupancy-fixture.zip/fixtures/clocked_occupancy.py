"""Offline hp-02 timing fixture. Requires Python 3.13 and the public files in source-lock.json."""
import argparse
import csv
from datetime import datetime, timedelta
from functools import lru_cache
import hashlib
import io
import json
from pathlib import Path
import signal
import sys
import tempfile
from unittest.mock import patch
from zoneinfo import ZoneInfo

SEAT = Path(__file__).resolve().parents[1]
INPUT = SEAT / "fixtures/inputs"
PIN = SEAT / "tmp/pin"
NATIVE = []


def block_native(event, args):
    if (event.startswith(("subprocess.", "socket.", "ctypes.", "pty.spawn"))
            or event in {"os.system", "os.exec", "os.posix_spawn", "os.spawn", "os.fork",
                         "os.forkpty", "os.kill", "os.killpg", "os.startfile", "os.execve",
                         "signal.pthread_kill"}):
        NATIVE.append(event)
        raise RuntimeError(f"native boundary crossed: {event}")


sys.addaudithook(block_native)
if not __debug__:
    raise RuntimeError("run without -O")
lock = json.loads((SEAT / "fixtures/source-lock.json").read_bytes())
for name, source in lock.items():
    if name.startswith("predecessor/") and not name.endswith("item-cases.json"):
        continue
    path = INPUT / "item-cases.json" if name.startswith("predecessor/") else SEAT / name
    if hashlib.sha256(path.read_bytes()).hexdigest() != source["sha256"]:
        raise ValueError(f"source digest mismatch: {path}")
sys.path.insert(0, str(PIN))
from joulewise.cadence import kit as kitmod, legs
from scripts import align_r1_rehearsal as r1, cadence_legs_runner as runner
from scripts import launch_align_r0 as base, launch_cadence_span as launcher

ZONE = ZoneInfo("America/Los_Angeles")
FRIDAY = datetime(2026, 11, 20, tzinfo=ZONE)
NOON = int(FRIDAY.replace(hour=12).timestamp())
AFTERNOON = int(FRIDAY.replace(hour=14).timestamp())
ARGS = ("02:00-02:35", "13:14-13:15")
KIT_PATH = INPUT / "cl-hp-02.json"
KIT, SHA = kitmod.load_kit(KIT_PATH)
ITEMS = {r["span"]: r for r in json.loads((INPUT / "items.json").read_bytes())}
SOAK = int(base.r1_soak_cap_s())
IDLE = next(seconds for name, _, seconds, _ in r1.phase_plan() if name == "idle_soak")
DWELL = base.DISPLAY_SLEEP_DWELL_S
# Wholly invented maxima for a clean fixture. No measured setup/IO/close bound is inferred.
RUNNER_LAG = 60
POST_FIXED = 100
SOAK_DISPATCH = 10
PER_ATTEMPT = 12
CLOSE = 180
OUTER = 190


def iso(t):
    return datetime.fromtimestamp(t, ZONE).isoformat()


@lru_cache(None)
def plan(span, window, t):
    try:
        return launcher.cadence_plan(KIT_PATH, ",".join(ITEMS[span]["legs"]), window, t0=t)
    except legs.PlanError as err:
        if len(err.problems) == 1 and "meets a batch blackout" in err.problems[0]:
            return None
        raise


def end_of_work(t, entry, p, argument, post_fixed):
    """Upper elapsed times. Each duration is charged at exactly one stage."""
    w = legs.parse_window(argument)
    c = runner.FakeClock(t)
    c.sleep(entry)
    delay = legs.interval_delay(c.time(), SOAK, [w, r1.OS_BATCH_WINDOW_LOCAL])
    c.sleep(delay)
    release = c.time() - t
    attempts = len(p["legs"]) + p["redo_quota"]
    dispatch = SOAK_DISPATCH if post_fixed else 0
    per_attempt = PER_ATTEMPT if post_fixed else 0
    c.sleep(dispatch)
    child_time = datetime.fromtimestamp(c.time(), ZONE)
    # Child's refusal callback, solely a clock test. No child or native sleep.
    def unexpected_sleep(seconds):
        raise AssertionError(f"inner soak would refuse at {child_time}: {seconds}")
    # Up to 100 invented seconds between child dispatch and its internal gate;
    # charged inside its 1950 s cap. Along with dispatch this is <= 150 s.
    inner_time = child_time + timedelta(seconds=100)
    r1.wait_outside_os_batch(IDLE, now=lambda: inner_time, sleep=unexpected_sleep)
    c.sleep(SOAK)
    leg_wait = 0
    for _ in range(attempts):
        c.sleep(per_attempt)
        wait = legs.leg_start_delay(c.time(), [w])
        leg_wait += wait
        c.sleep(wait + p["leg_cap_s"])
    remaining_fixed = post_fixed - dispatch - attempts * per_attempt
    assert remaining_fixed >= 0
    c.sleep(remaining_fixed)
    return dict(entry_s=entry, soak_wait_s=int(delay), release_s=int(release),
                leg_wait_s=int(leg_wait), work_s=int(c.time()-t))


def envelope(span, argument, t, entry_max=None):
    p = plan(span, argument, t)
    if p is None:
        return dict(decision="REFUSE_PLAN")
    item = ITEMS[span]
    w = p["worst_case_s"]
    f = item["deadline_s"]
    assert w == item["worst_case_s"] and f == w + 1460
    minimum = int(launcher.cadence_minimum_seconds(p))
    assert minimum == w + 560 and f >= minimum
    tail = SOAK + (len(p["legs"]) + p["redo_quota"]) * p["leg_cap_s"]
    guard_max = f - runner.WORK_RESERVE_S - tail
    assert guard_max == 2290 and p["fixed_overhead_s"] == w - tail == 1200
    # At most 1100 s through the delay sample plus 100 s outside the child caps
    # throughout the rest of work. This *allocates* the template's 1200 s once.
    hi = (p["fixed_overhead_s"] - POST_FIXED) if entry_max is None else entry_max
    if not DWELL <= hi <= guard_max:
        return dict(decision="WAIT_EVIDENCE")
    result = end_of_work(t, hi, p, argument, POST_FIXED)
    # Envelope over every possible runner start in [t,t+60]. The union of
    # translated half-open work intervals is [t,t+60+w). End-touch passes.
    stable = legs.blackout_bound_s(t, w+RUNNER_LAG, [legs.parse_window(argument)]) == 0
    # Separate diagnostic: *if* the guard and selector are co-timed and all
    # non-child service after entry is instantaneous, take the entire guard
    # range. This illustrates the pin's guard, not a desk-supplied IO bound.
    frontier = end_of_work(t, guard_max, p, argument, 0)
    cut = f - runner.WORK_RESERVE_S
    fence_clock = runner.FakeClock(t + result["work_s"])
    fence_clock.sleep(CLOSE)  # joint bound for restore/readbacks, feed stops, writes and clean exit
    close_end = int(fence_clock.time()-t)
    fence_clock.sleep(OUTER)  # invented bound on wrapper clearance, inside the original fence
    required = int(fence_clock.time()-t)
    headroom = f - required
    assert f-cut == CLOSE+OUTER == runner.WORK_RESERVE_S
    assert f - base.R1_CLEANUP_GRACE_S - 10 == cut + CLOSE
    decision = "WITHHOLD_REPLAN" if not stable else "CEDE_FENCE" if headroom < 0 else "ELIGIBLE"
    return dict(**result, plan_s=w, minimum_s=minimum, deadline_s=f, guard_max_s=guard_max,
                guard_frontier_work_s=frontier["work_s"], guard_frontier_slack_s=cut-frontier["work_s"],
                work_cutoff_s=cut, close_end_s=close_end, required_s=required, headroom_s=headroom,
                # Protect the entire existing fence when it fits. A negative row is demand only.
                protected_s=f if decision=="ELIGIBLE" else None,
                decision=decision)


def picked(span, t, entry_max=None):
    for a in ARGS:
        row = envelope(span, a, t, entry_max)
        if row["decision"] != "REFUSE_PLAN":
            return a, row
    return None, dict(decision="REFUSE_PLAN")


def runner_trace(span, t, lag, entry, *, production_window=True, cap_paced=True,
                 faults=("close_restore_fails_once",), journal_lag=0, arg=None, timed_close=False):
    """Run the pin's real control flow using owned fake clock/feeds/host. Never call launch or production_deps."""
    arg = arg or picked(span, t)[0]
    p = plan(span, arg, t)
    ids = ITEMS[span]["legs"]
    c = runner.FakeClock(t)
    c.sleep(lag)
    assert entry >= lag + DWELL
    with tempfile.TemporaryDirectory(dir=SEAT/"tmp") as tmp:
        out = Path(tmp)/"span"
        deps = runner.mock_deps(out, c, contaminate=ids[:2], power_faults=faults)
        assert deps.soak_windows == [] and deps.soak_cap_s == SOAK
        if production_window:
            deps.soak_windows = [r1.OS_BATCH_WINDOW_LOCAL]
        def setup(_):
            c.sleep(entry - lag - DWELL)
            return {"rc": 0, "mock": True}
        deps.verify_frozen = setup
        def pace(call):
            def child(path, *args):
                cap, _, remaining = args[-3:]
                if remaining() < cap:
                    raise runner.SpanRefusal(f"fixture replay of run_child cap check: {path.name}", 3)
                start = c.time()
                value = call(path, *args)
                if cap_paced:
                    # Production stops at the cap. A successful attempt takes cap-1 s here.
                    padding = cap - 1 - (c.time() - start)
                    assert padding >= 0
                    c.sleep(padding)
                    if isinstance(value, dict):
                        # The pin checks sample coverage against the clocked wall.
                        # Extend only the owned fake load journal by its fake value.
                        seconds = int(c.time() - start)
                        value["cpu_busy_cores"] = [value["cpu_busy_cores"][0]] * seconds
                        value["cpu_busy_t_s"] = list(range(seconds))
                return value
            return child
        deps.run_leg = pace(deps.run_leg)
        deps.run_soak = pace(deps.run_soak)
        journal_end = legs.StageJournal.end
        def finish_stage(self, name, *args):
            journal_end(self, name, *args)
            if name == "plan":
                c.sleep(journal_lag)
        close_phase = False
        journal_start = legs.StageJournal.start
        def begin_stage(self, name, *args):
            nonlocal close_phase
            if name == "power_last_look":
                close_phase = True
            return journal_start(self, name, *args)
        def fake_power(argv):
            if timed_close and close_phase:
                c.sleep(15)
            return deps.host.pmset(argv)
        deps.host.power_runner = lambda: fake_power
        samples = []
        delay_fn = legs.interval_delay
        def sample(epoch, cap, windows):
            delay = delay_fn(epoch, cap, windows)
            samples.append((epoch-t, delay))
            return delay
        with (patch.object(legs.StageJournal, "start", begin_stage),
              patch.object(legs.StageJournal, "end", finish_stage),
              patch.object(legs, "interval_delay", sample),
              patch.object(signal, "signal", return_value=signal.SIG_DFL),
              patch("time.time", c.time), patch("time.monotonic", c.monotonic),
              patch("time.sleep", side_effect=AssertionError("real sleep")),
              patch("os.getpid", return_value=10101)):
            rc = runner.run_span(kit=KIT, kit_sha256=SHA, output=out, windows=[legs.parse_window(arg)],
                                 deadline=t+ITEMS[span]["deadline_s"], deps=deps, leg_ids=ids)
        receipt = json.loads((out/runner.RECEIPT_NAME).read_bytes())
        assert receipt["mock"] and receipt["roster"] == ids and receipt["batch_windows"] == [arg]
        assert receipt["kit"]["sha256"] == SHA and receipt["started"]["epoch_s"] == t+lag
        high = receipt["high_power"]
        steps = {s["name"]:s for s in receipt["steps"]}
        # The wrapper is never invoked. Model a *successful* synthetic clear
        # after this runner returns. Restore and rc still independently gate reuse.
        assert c.time() == receipt["ended"]["epoch_s"]
        c.sleep(OUTER)
        result = dict(span=span, t0=iso(t), argument=arg, lag_s=lag, entry_requested_s=entry,
                      journal_lag_s=journal_lag, production_window=production_window, cap_paced=cap_paced,
                      rc=rc, plan_rc=steps["plan"]["rc"], error=receipt.get("error"),
                      sampled_entry_s=samples[0][0] if samples else None,
                      delay_s=samples[0][1] if samples else None,
                      soak_started_s=steps["soak"]["started"]["epoch_s"]-t if "soak" in steps else None,
                      work_until_close_s=steps["power_last_look"]["started"]["epoch_s"]-t,
                      close_end_s=receipt["ended"]["epoch_s"]-t, legs_finished=receipt["legs_finished"],
                      timed_close=timed_close, simulated_fence_clear_s=c.time()-t,
                      simulated_fence_headroom_s=t+ITEMS[span]["deadline_s"]-c.time(),
                      restore_attempts=high["restore"].get("attempts"), restore_proven=high["close_proof"]["proven"])
        return result


def boundaries(span):
    p = plan(span, ARGS[0], AFTERNOON)
    w = p["worst_case_s"]
    points = {NOON, AFTERNOON, NOON+38*60+30, NOON+45*60}
    for midnight in (FRIDAY, FRIDAY+timedelta(days=1)):
        day = int(midnight.timestamp())
        points.add(day)
        for win in [*map(legs.parse_window, ARGS), r1.OS_BATCH_WINDOW_LOCAL]:
            (h,m),(h1,m1) = win
            start, end = day+(60*h+m)*60, day+(60*h1+m1)*60
            points.update([start, end, start-w, start-w-RUNNER_LAG])
            for offset in [0,DWELL,1100,1200,2290]:
                points.update([start-SOAK-offset, start-offset, end-offset])
    return sorted({t+d for t in points for d in (-1,0,1)})


def dated_pair(t, span, first_to_second, *, floor, transfer, latest):
    arg, row = picked(span,t)
    assert row["decision"] == "ELIGIBLE"
    # Invented counted pins accept all seconds on this assigned date at/after
    # the supplied floor. first_to_second includes its close/transition already.
    first = max(floor, t + row["protected_s"] + transfer)
    last = first + first_to_second
    return dict(span=span,t0=iso(t),argument=arg,transfer_s=transfer,first_to_second_s=first_to_second,
                first=iso(first),latest_first=iso(latest-first_to_second),last=iso(last),latest=iso(latest),
                slack_s=latest-last,decision="ELIGIBLE" if last<=latest else "CEDE_DATED")


def validate(write):
    def save(name, rows):
        out = io.StringIO(newline="")
        writer = csv.DictWriter(out,fieldnames=list(dict.fromkeys(k for row in rows for k in row)),lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
        path = SEAT/"fixtures"/name
        if write:
            path.write_bytes(out.getvalue().encode())
        else:
            assert path.read_bytes() == out.getvalue().encode(), f"replay differs: {name}"
    assert set(ITEMS) == {"hp-02-s01","hp-02-s02","hp-02-s03"}
    assert plan("hp-02-s01", ARGS[0], NOON)["worst_case_s"] == 16650
    assert legs.interval_delay(NOON,SOAK,[r1.OS_BATCH_WINDOW_LOCAL]) == 4500
    assert SOAK==1950 and DWELL==300 and base.R1_CLEANUP_GRACE_S==180
    assert r1.OS_BATCH_WINDOW_LOCAL==((11,45),(13,15))
    matrix, traces, pairs = [], [], []
    for span,item in ITEMS.items():
        for t in boundaries(span):
            chosen,_ = picked(span,t)
            for arg in ARGS:
                row=envelope(span,arg,t)
                matrix.append(dict(span=span,t0=iso(t),argument=arg,selected=chosen==arg,**row))
        for arg in ARGS:
            (h,m),(eh,em)=legs.parse_window(arg)
            lo=int(FRIDAY.replace(hour=h,minute=m).timestamp())
            end=int(FRIDAY.replace(hour=eh,minute=em).timestamp())
            w=item["worst_case_s"]
            for t,ok in [(lo-w-1,True),(lo-w,True),(lo-w+1,False),
                         (lo-1,False),(lo,False),(lo+1,False),(end-1,False),(end,True),(end+1,True)]:
                assert bool(plan(span,arg,t)) == ok
        # Selector transition, using a real permitted clock offset, at ±1 s.
        start=int(FRIDAY.replace(hour=11,minute=45).timestamp())
        end=int(FRIDAY.replace(hour=13,minute=15).timestamp())
        for off in (DWELL,1100,1200,2290):
            for edge,expected in ((start-SOAK,[0,0,end-start+SOAK-1]),(end,[1,0,0])):
                for diff,delay in zip((-1,0,1),expected):
                    t=edge-off+diff
                    p=plan(span,ARGS[0],t)
                    assert end_of_work(t,off,p,ARGS[0],0)["soak_wait_s"] == delay
        noon_arg,noon=picked(span,NOON)
        assert noon_arg==ARGS[0] and noon["decision"]=="CEDE_FENCE" and noon["headroom_s"]==-2310
        assert picked(span,AFTERNOON)[1]["headroom_s"] == 1090
        assert picked(span,AFTERNOON)[1]["decision"] == "ELIGIBLE"
        overnight=int(FRIDAY.replace(hour=23,minute=59,second=59).timestamp())
        assert picked(span,overnight)[0]==ARGS[1] and picked(span,overnight)[1]["decision"]=="ELIGIBLE"
        for t,lag,e,live_win,paced in [(NOON,0,DWELL,False,True),(NOON,0,DWELL,True,True),
                (NOON,60,1200,True,False),(NOON,60,2290,True,True),(AFTERNOON,60,1200,True,True),
                (AFTERNOON,60,2290,True,True),(AFTERNOON,60,2291,True,True),(overnight,60,1100,True,True)]:
            row=runner_trace(span,t,lag,e,production_window=live_win,cap_paced=paced)
            traces.append(row)
            if e==2291:
                assert row["plan_rc"] and row["sampled_entry_s"] is None
            else:
                assert row["plan_rc"]==0 and row["sampled_entry_s"]==e
                delay=4500-e if live_win and t==NOON else 0
                assert row["delay_s"]==delay and row["soak_started_s"]==e+delay
                assert (row["rc"]==3) if t==NOON and live_win and paced else (row["rc"]==0)
                assert row["restore_proven"] and row["restore_attempts"]==2
        # Successful cap-paced path with real additional wait, still inside the fence.
        half=int(FRIDAY.replace(hour=12,minute=45).timestamp())
        row=runner_trace(span,half,0,DWELL)
        assert row["rc"]==0 and row["work_until_close_s"]>item["worst_case_s"]
        assert row["delay_s"]==1500 and row["restore_proven"]
        traces.append(row)
        close_trace=runner_trace(span,half,60,1100,timed_close=True)
        assert close_trace["rc"]==0 and close_trace["restore_proven"]
        assert close_trace["close_end_s"]-close_trace["work_until_close_s"]==77
        assert close_trace["simulated_fence_headroom_s"]>=0
        traces.append(close_trace)
        # Prove 2290 bounds the guard sample, not later journal/IO timestamps.
        row=runner_trace(span,AFTERNOON,60,2290,journal_lag=1)
        assert row["plan_rc"]==0 and row["sampled_entry_s"]==2291
        traces.append(row)
        # Same physical second relative to the frozen gate, opposite side
        # of a half-open soak boundary. Both runner re-plans still pass.
        morning = int(FRIDAY.replace(hour=10,minute=50).timestamp()) + 86400
        assert any(lo <= morning <= hi and argument == ARGS[0] for lo,hi,argument in item["bands"])
        for e, expected_delay in [(1350,0),(1351,7349)]:
            probe = runner_trace(span,morning,60,e)
            assert probe["sampled_entry_s"] == e and probe["delay_s"] == expected_delay
            assert probe["rc"] == (0 if not expected_delay else 3)
            traces.append(probe)
        # Arm plan at end-touch passes; the very same argument at runner
        # start, a second later, refuses. The plan's origin is the runner stamp.
        edge = int(FRIDAY.replace(hour=2).timestamp()) - item["worst_case_s"]
        row = runner_trace(span,edge,1,301,arg=ARGS[0])
        assert row["plan_rc"] and row["sampled_entry_s"] is None and "batch blackout" in row["error"]
        traces.append(row)
        for d in (-1,0,1):
            _, row = picked(span,NOON+2310+d)
            assert row["headroom_s"] == d and row["decision"] == ("ELIGIBLE" if d>=0 else "CEDE_FENCE")
        # Counted dates here are invented. Protect the entire fence plus a
        # demonstrated outstanding 600 s transfer bound after fence release.
        latest=int(FRIDAY.replace(hour=23,minute=59,second=59).timestamp())
        floor=AFTERNOON+900
        for slack in (1,0,-1):
            dur=latest-AFTERNOON-item["deadline_s"]-600-slack
            row=dated_pair(AFTERNOON,span,dur,floor=floor,transfer=600,latest=latest)
            assert dur>0 and floor+dur<=latest and row["slack_s"]==slack
            assert row["decision"]==("ELIGIBLE" if slack>=0 else "CEDE_DATED")
            pairs.append(row)
    bad=runner_trace("hp-02-s01",AFTERNOON,0,DWELL,faults=("close_restore_fails",))
    assert bad["rc"] and not bad["restore_proven"] and bad["restore_attempts"]==3
    traces.append(bad)
    cases=json.loads((INPUT/"item-cases.json").read_bytes())
    trace=[]
    for r in cases["cases"]:
        k=r["id"]
        ref="fixtures/inputs/item-cases.json#/cases/"+str(len(trace))
        action="inherited expectation; successor entry points pending"
        if k in {"pair-equality","pair-plus-one"}:
            t=int(datetime.fromisoformat(cases["base"]["clock"]).timestamp())
            specs=r["observations"]["dated_pending"][0]
            pair=dated_pair(t,"hp-02-s01",specs["first_to_second_s"],
                            floor=int(datetime.fromisoformat(specs["t0_floor"]).timestamp()),transfer=0,
                            latest=int(datetime.fromtimestamp(t,ZONE).replace(hour=23,minute=59,second=59).timestamp()))
            assert r["expected_successor"]==pair["decision"]
            assert pair["slack_s"] == (0 if k=="pair-equality" else -1)
            pairs.append(pair)
            action="original counted-pair arithmetic executed in counted-pairs.csv"
        obs = r["observations"]
        clock = r.get("clock", cases["base"]["clock"])
        which_span = obs.get("span",cases["base"]["span"])
        arg, projection = picked(which_span,int(datetime.fromisoformat(clock).timestamp()))
        trace.append(dict(id=k,source=ref,clock=clock,span=which_span,argument=arg,
                          conditional_clock_only=projection["decision"],phase=r["observations"].get("phase","issue/Start/Run as specified"),
                          expected_successor=r["expected_successor"],coverage=action))
    assert cases["synthetic_only"] and len({x["id"] for x in trace})==len(trace)==60
    save("clock-matrix.csv",matrix)
    save("runner-traces.csv",traces)
    save("counted-pairs.csv",pairs)
    save("vector-index.csv",trace)
    assert not NATIVE
    print(f"PASS {len(matrix)} explicit clock plans, {len(traces)} clocked runner traces, {len(pairs)} dated pairs, "
          f"{len(trace)} inherited vector IDs; native attempts {len(NATIVE)}")
    for span in ITEMS:
        for t in (NOON,AFTERNOON):
            a,r=picked(span,t)
            print(span,iso(t),a,r["work_s"],r["required_s"],r["headroom_s"],r["decision"])


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write-evidence", action="store_true")
    validate(parser.parse_args().write_evidence)
