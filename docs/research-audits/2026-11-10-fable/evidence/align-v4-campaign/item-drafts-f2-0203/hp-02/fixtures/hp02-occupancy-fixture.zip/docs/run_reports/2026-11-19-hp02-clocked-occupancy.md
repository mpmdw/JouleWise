# hp-02 clocked occupancy handoff, 19 November 2026

**Disposition for the lead.** Freeze the HP-only timing test for builder review. A noon launch plan admits all three rosters, but their complete cap workloads cannot fit their existing fences. An afternoon launch can fit on affirmative, bounded inputs. Actual issue remains on hold. [Freeze addendum](../../FREEZE-ADDENDUM.md)

**New head and CI.** Seat-only delivery, zero repository commits, no PR and no CI run. The pin remains `dd206025abb30fd5c07515cd4b34b3e653174810`. The initial `git status --short --branch` in the supplied astra-main checkout failed because its linked Git directory was inaccessible. No PR was assigned; the public remote returned no astra-main or matching occupancy branch. An ancestry comparison or fast-forward of that checkout was therefore inapplicable to this seat delivery. The checkout, audit branch, pins, item drafts, RUN_STATE and TASK_QUEUE were left alone.

## Revisions and bytes

| Source | Exact revision or SHA-256 |
|---|---|
| Launcher, runner, pure functions and transitive public Python source | `dd206025abb30fd5c07515cd4b34b3e653174810`. Each copied public path was checked against its Git blob ID. Paths, revisions, blob IDs and SHA-256 values are in `fixtures/source-lock.json`, SHA-256 `58e7eee87af97f6034af0bc0bce591aa612c7e34a35266534c3d2610b285ad57`. |
| Public item generator, descriptors, and frozen kit used only as planner input | Audit `9a5a9be30027d90a5ec69f1820b3f8a081d664de`. Generator `0273317e600512eb28d91e57b9c0c1f65fdf81d99a8e8193317de49485acc507`, items `65a15626b53e2d69da1c69da9701d8f84f0d90a317cb57d5e24f62180993a5d2`, kit `7693b8293b42b8ba20cbd321e201974745b172dc53c4f1397d2c1494f38fbe66`. The kit delta was already admitted. |
| RLD | File `docs/research-audits/2026-11-10-fable/RESEARCH-LEAD-DECISIONS.md`. The specified six inclusive slices at the audit revision above and at the observed remote audit head `c39ec79931db9da0155cc39623ca9f581e4aebb7` match the supplied ruling text. Concatenated slices in requested order, preserving line endings, SHA-256 `81af2300cd6cfb3ba4b4b421cb957ead01b1d4ac54ebe53f5826ea5c3c20cee4`. Observed public main `366dcf9c8dc8622e07a90714d9033dbfbf5fa842` served only as remote metadata. |
| Predecessor seat | `ITEM-GATES-SPEC.md` SHA-256 `24331d02ebf8d2172f9ebce5866c44e80208b8c5145c18a08c4124acaf3de73a`; `fixtures/check_contract.py` `c73506b716e770c1590bcb6bf5b5e7d10eb7c194a60b24249952e008eca1223b`; `fixtures/item-cases.json` `fa13f60290d7830a69b77a3e0734378009bca15a18a8498d94b253924a9ac8dd`. |
| Freeze candidate and executable regression | Addendum SHA-256 `77f34fae9bd88ae415d7b949ef6ea6ac68759b1ef47aec214a50c32317ad99c4`. `fixtures/clocked_occupancy.py` `0dd80986db218ece84fbea2c7612390d414c2be4bde6bb20532dcb7aca70e725`. `fixtures/successor_regression.py` **`f28df8c505128d360de4345cb16fec4a7d1f7575fcda451b627c72c3decf3aab`**. |

## Findings and verification

| Finding | Public commit | Regression | Expected and observed |
|---|---|---|---|
| Plan-only occupancy understates a completing span. At 12:45 the work measured on the owned clock is 17,244 / 19,943 / 22,642 s against 16,650 / 19,350 / 22,050 s. | dd206025a | `runner_trace`, cap-paced soak/legs with two redos and proven mock restore | PASS; rc 0 for all three. No desk acceptance is inferred. |
| The component witnesses and earliest noon runner path differ. At 12:05 the wait is 4,200 s. A 12:00 hypothetical selector waits 4,500 s. | dd206025a | `replay_contract.py` and noon traces with/without the production soak window | PASS; the cap-paced production-window version refused a later leg (rc 3); the stock mock completed. Under the bounded invented profile, all three cede with a 2,310 s deficit; all three are eligible at 14:00 with 1,090 s spare. |
| Guard accepts +2,290 and refuses +2,291; a post-guard journal second can move the selector past +2,290. At the old 10:50 band, +1,350 versus +1,351 yields 0 versus 7,349 s wait. A one-second runner start shift can independently turn an accepted arm plan into a re-plan refusal. | dd206025a; descriptors 9a5a9be3 | Guard, old-band and re-plan witnesses in `runner-traces.csv` | PASS for every span. Half-open boundaries in both arguments and overnight rollover in `clock-matrix.csv` passed. |
| Restore timing and release are distinct. A single synthetic failure then success takes two restore attempts; three persistent failures leave restore unproven. | dd206025a | Timed close and persistent-failure rows in `runner-traces.csv` | PASS. Scripted command service plus retry sleeps gave 77 s on the timed trace. Wrapper/clear was simulated. |
| Counted start with +1 s and equality fits; the one-second miss cedes. All original IDs retain their proposed decisions. | RLD c39ec799, original vectors by digest | `counted-pairs.csv`, `vector-index.csv`, original checker | PASS; nine new span-specific pairs and both inherited pairs; 60 distinct JSON pointers. All non-timing successor decisions await the builder. |
| Fresh Start and Run must carry a bounded composed projection. | dd206025a; item inputs 9a5a9be3 | `successor_regression.py` | Expected RED, observed exit 1, 27/54 mismatches for a deliberately plan-only control. Expected GREEN, observed exit 0, 54/54 against the composed reference. A successor candidate has not been supplied. |

The complete matrix contains 1,764 explicit clock/argument/roster rows, 43 pinned-runner traces, 11 counted pairs and the 60-case index. The repeated fixture verified each saved CSV byte-for-byte. The clocked process recorded zero native-command attempts. Fixture tests used only public source and invented inputs. The native launcher, measurement host and restricted data were outside the execution path.

## Reproduce

Run in `/Volumes/JW-EXT/scratch/d-hp02-full-occupancy-spec` or in the unpacked delivery. Python 3.13 with standard-library IANA zone information suffices. The integration script verifies its input digests and installs its process/network trap before importing the pin.

```sh
python3.13 -I -B fixtures/replay_contract.py
python3.13 -I -B fixtures/clocked_occupancy.py
python3.13 -I -B fixtures/successor_regression.py --reference
python3.13 -I -B fixtures/successor_regression.py
```

The first three commands exit 0. The last exits 1 and prints each false permission. It reuses the actual pure pin planner with the draft's fence as the negative control. It does not purport to run a completed successor. Use `python3.13 -I -B fixtures/clocked_occupancy.py --write-evidence` only to regenerate the four local CSVs.

For the future builder, export normalized *observations* from both actual HP entry points under the supplied synthetic inputs. The original checker takes its separate 60-ID map. These candidate commands require builder outputs.

```sh
python3.13 -I -B fixtures/successor_regression.py --inputs > tmp/successor-inputs.json
python3.13 -I -B fixtures/successor_regression.py --candidate tmp/successor-observed.json
python3.13 -I -B fixtures/replay_contract.py --decisions tmp/original-60-observed.json
```

Public revision checks used by this seat can be reproduced from the previous public-only cache. The last pipeline selects only the requested ruling ranges.

```sh
git ls-remote --heads https://github.com/mpmdw/JouleWise.git refs/heads/main refs/heads/audit/2026-11-10-fable refs/heads/astra-main '*occupancy*'
pin_repo=/Volumes/JW-EXT/scratch/d-hp02-post-r1-issuability/tmp/pin
git -C "$pin_repo" rev-parse HEAD
git -C "$pin_repo" ls-tree dd206025abb30fd5c07515cd4b34b3e653174810 -- scripts/launch_cadence_span.py scripts/cadence_legs_runner.py scripts/align_r1_rehearsal.py
ruling_path=docs/research-audits/2026-11-10-fable/RESEARCH-LEAD-DECISIONS.md
git -C "$pin_repo" show "c39ec79931db9da0155cc39623ca9f581e4aebb7:$ruling_path" | sed -n '17586,17590p;17854,17862p;18644,18686p;18734,18742p;18819,18825p;19118,19132p' | shasum -a 256
```

## Disagreements and NEEDS_SPEC

The earlier noon probes were correct individually. Their juxtaposition did not establish the launch-to-entry offset, total work or fence fit. The 1,200-second allowance is a plan budget, the 2,290-second limit belongs to the post-dwell gate, and the 30/180-second handoff parameters govern only parts of launch. None certifies an absolute bound on successful fence clearance. The integration fixture keeps those distinctions executable. During fixture construction, cap-paced legs initially tripped the pin's load-journal completeness check because the fake samples covered only the original shorter duration. The fixture now extends the wholly invented journal to the same elapsed wall time and executes the original load verdict.

**No new frozen-pin or paper ruling is needed for this timing finding.** The prior line-2 applicability question remains with Opus, with Fable as the ruling route if the admission register is silent. Any desired change to the frozen behavior or paper scope goes to Fable. Live time bounds, positive no-prior-look attestation, queue admission and dates, dated contention, predecessor and safety proofs, acceptance and actual issue remain with their authorized owners. No approval or host observation was obtained here.

**Next exact step.** Opus reviews the addendum and regression digests against ITEM-GATES-SPEC lines 84–99. After freeze, the HP builder implements the paths listed in the addendum and returns the two observed maps for independent execution at its exact candidate commit.
