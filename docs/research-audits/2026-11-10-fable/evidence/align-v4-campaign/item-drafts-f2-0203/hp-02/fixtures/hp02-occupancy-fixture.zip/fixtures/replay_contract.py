"""Run the original 60-vector integrity checker under the same native-command trap."""
import runpy
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import clocked_occupancy as f

src = f.INPUT / "check_contract.py"
assert f.hashlib.sha256(src.read_bytes()).hexdigest() == f.lock["predecessor/fixtures/check_contract.py"]["sha256"]
with tempfile.TemporaryDirectory(dir=f.SEAT / "tmp") as scratch:
    root = Path(scratch)
    fixtures = root / "fixtures"
    fixtures.mkdir()
    draft = root / "tmp/drafts/hp-02"
    draft.mkdir(parents=True)
    (root / "tmp/pin").symlink_to(f.PIN)
    (draft / "cl-hp-02.json").symlink_to(f.KIT_PATH)
    (fixtures / "item-cases.json").symlink_to(f.INPUT / "item-cases.json")
    # The original resolves its own __file__ to discover this layout.
    script = fixtures / "check_contract.py"
    script.write_bytes(src.read_bytes())
    runpy.run_path(str(script), run_name="__main__")
assert not f.NATIVE
