"""Named stops: the only conditions that page the lead and the research lead per span.

``evaluate_named_stops`` takes a span's operational summary (no energy) and the
campaign history, and returns the stops that fire. Anything else a span shows
is recorded by its predeclared disposition and does not page anyone.

| Code | Fires when |
|---|---|
| REFUSAL | the results ref is not a clean completion (chain exit code non-zero, outcome not COMPLETE, or no result by the deadline). ``verdict: GO`` alone is never success |
| INSTRUMENT_FAULT | ``fault`` true, the KM003C capture missing, a feed not proven stopped, meter bad polls or USB errors above zero |
| CONTAMINATED_REDOS | contaminated redos (scope span or campaign) reach ``contaminated_redos_max`` |
| LEG_OVERTIME | two legs of the span exceed ``leg_time_factor`` x their budget (a leg with no wall or budget recorded counts) |
| RESTORE_UNPROVEN | a High Power span (``block_mode`` 2, the kit's ``power_mode``) whose result does not say ``restore_proven: true``: false, absent, or no result at all (SIGKILL, power loss, a lost receipt). For any span, an explicit ``restore_proven: false``. RL-149 sections 2.4 and 2.5; it holds everything |

RL-149 section 2.4 (it governs this table): LEG_OVERTIME needs two legs in a span, and
BAND_UNREACHABLE is dropped ("bands are by history; nothing is reached for"). The kit's
``band_unreachable_*`` keys stay in schema v1 and no stop reads them.

Span summary shape (all operational): ``{"result": {chain_exit_code, chain_outcome, fault, outcome[, restore_proven]},
"meter": {present, proven_stopped, bad_polls, usb_errors}, "feeds_proven_stopped": bool,
"legs": [{leg_id, wall_s, budget_s, start_band, band_reached, contaminated_redos}]}``.
"""
from __future__ import annotations

from joulewise.cadence import kit as kitmod
from joulewise.cadence.queue import result_ok

CODES = ("REFUSAL", "INSTRUMENT_FAULT", "CONTAMINATED_REDOS", "LEG_OVERTIME", "RESTORE_UNPROVEN")
LEG_OVERTIME_LEGS = 2   # RL-149 section 2.4: "two legs over 1.5 x their budget in a span"


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def evaluate_named_stops(rules, span, history=(), block_mode=kitmod.AUTOMATIC):
    """Return [{code, detail}] for one span. ``history`` holds earlier span summaries of the campaign.
    ``block_mode`` is the kit's power mode: for a High Power block only ``restore_proven: true`` proves the
    close (cold seat F1: an absent proof is a stop)."""
    stops = []
    result = span.get("result")
    if result is None:
        stops.append({"code": "REFUSAL", "detail": "no terminal result"})
    elif not result_ok(result) and result.get("fault") is not True:
        stops.append({"code": "REFUSAL", "detail": (
            f"chain_exit_code={result.get('chain_exit_code')} chain_outcome={result.get('chain_outcome')} "
            f"outcome={result.get('outcome')}")})
    proven = None if result is None else result.get("restore_proven")
    if proven is False or (block_mode == kitmod.HIGH_POWER and proven is not True):
        why = ("the close did not prove AC powermode 0 and no High Power marker" if proven is False else
               "a High Power span left no proof of its restore (no result, or no restore_proven)")
        stops.append({"code": "RESTORE_UNPROVEN",
                      "detail": f"{why}; it holds everything until the lead restores and records it"})
    meter = span.get("meter") or {}
    faults = []
    if result is not None and result.get("fault") is True:
        faults.append("result fault")
    if meter.get("present") is not True:
        faults.append("KM003C capture missing")
    if meter.get("proven_stopped") is not True:
        faults.append("meter feed not proven stopped")
    for key in ("bad_polls", "usb_errors"):
        if not _num(meter.get(key)) or meter[key] > 0:
            faults.append(f"meter {key} {meter.get(key)}")
    if span.get("feeds_proven_stopped") is not True:
        faults.append("a feed not proven stopped")
    if faults:
        stops.append({"code": "INSTRUMENT_FAULT", "detail": "; ".join(faults)})

    legs = span.get("legs") or []
    pool = list(legs)
    if rules["contaminated_redos_scope"] == "campaign":
        pool = [leg for past in history for leg in past.get("legs") or []] + pool
    redos = sum(int(leg.get("contaminated_redos") or 0) for leg in pool)
    if redos >= rules["contaminated_redos_max"]:
        stops.append({"code": "CONTAMINATED_REDOS",
                      "detail": f"{redos} contaminated redos ({rules['contaminated_redos_scope']})"})

    over = []
    for leg in legs:
        wall, budget = leg.get("wall_s"), leg.get("budget_s")
        if not (_num(wall) and _num(budget) and budget > 0):
            over.append(f"{leg.get('leg_id')}: wall or budget not recorded")
        elif wall > rules["leg_time_factor"] * budget:
            over.append(f"{leg.get('leg_id')}: {wall:.0f} s > {rules['leg_time_factor']} x {budget:.0f} s")
    if len(over) >= LEG_OVERTIME_LEGS:
        stops.append({"code": "LEG_OVERTIME", "detail": "; ".join(over)})
    return stops
